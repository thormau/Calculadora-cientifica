# Calculadoras JavaFX — V1.0, V2.0 y V3.0

Tres proyectos Maven independientes, listos para abrir y ejecutar en Visual Studio Code.

```
CalculadoraV1/  → pom.xml + src/main/java/com/mycompany/calculadora/CalculadoraV1.java
CalculadoraV2/  → pom.xml + src/main/java/com/mycompany/calculadora/CalculadoraV2.java
CalculadoraV3/  → pom.xml + src/main/java/com/mycompany/calculadora/CalculadoraV3.java
```

## Requisitos

- JDK 17 o superior (JDK 21 recomendado)
- Maven (o el Maven integrado de VS Code)
- Extensiones de VS Code: **Extension Pack for Java** y **Maven for Java**

No es necesario descargar el SDK de JavaFX por separado: cada `pom.xml` declara
`org.openjfx:javafx-controls:21.0.2` y Maven lo descarga automáticamente.

## Cómo ejecutar

Abre **una** de las tres carpetas en VS Code (File → Open Folder) y en la terminal:

```bash
mvn clean javafx:run
```

Para compilar sin ejecutar:

```bash
mvn clean compile
```

Si prefieres ejecutar con F5, crea `.vscode/launch.json` con:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "java",
      "name": "Calculadora",
      "request": "launch",
      "mainClass": "com.mycompany.calculadora.CalculadoraV3",
      "vmArgs": "--module-path ${env:PATH_TO_FX} --add-modules javafx.controls"
    }
  ]
}
```

(cambia `mainClass` según la versión y define `PATH_TO_FX` apuntando a la carpeta `lib`
de tu SDK de JavaFX; con `mvn javafx:run` esto no hace falta).

## Qué implementa cada versión

| | V1.0 | V2.0 | V3.0 |
|---|---|---|---|
| Operaciones +, -, *, / | Sí | Sí | Sí |
| Error "Error: División entre 0" y cierre | Sí | Sí | Sí |
| CE / C–AC, display en 0 | Sí | CE reemplazado por ⌫ y AC | Sí |
| ANS (resultado anterior) | Sí | Sí (acumulativo) | Sí |
| Máximo 2 decimales, precisión interna completa | Sí | Sí | Sí |
| Entrada por botones | Sí | Sí | Sí |
| Entrada por teclado físico | — | Sí | Sí |
| Historial en el renglón superior | Sí | Sí | Sí |
| Panel de historial de la sesión | — | Sí | Sí |
| Porcentaje (%) y +/- | +/- | Sí | Sí |
| Memoria MC / MR / M+ / M- | — | — | Sí |
| Geometría de botones | Redondos | Redondos | **Cuadrados** |
| Paleta | Dark Mode, operadores azules, C/CE rojos | Dark Mode, operadores ámbar, controles verde oliva | Dark Mode, dígitos claros, memoria en verde |

Toda la interfaz y los mensajes están en español, y la memoria (M) es independiente de
ANS y de C/AC: sólo MC la reinicia.
