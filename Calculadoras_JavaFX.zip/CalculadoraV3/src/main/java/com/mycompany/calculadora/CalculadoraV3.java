package com.mycompany.calculadora;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Calculadora V3.0 - Modelos de Prueba de Software
 *
 * Agrega sobre la V2.0 el modulo de acumulacion de valores en memoria:
 *  RF08 MR - Muestra el resultado que tenga la memoria en ese momento
 *  RF09 MC - Limpia el valor de la memoria y lo deja en 0
 *  RF10 M+ - Incrementa el valor que tenga MR
 *  RF11 M- - Decrementa el valor que tenga MR
 *  RNF07 Botones cuadrados
 *  RNF08 Fondo oscuro con digitos y operandos claros
 *  RNF09 Bloque de memoria diferenciado cromaticamente
 */
public class CalculadoraV3 extends Application {

    private final StringBuilder entrada = new StringBuilder("0");
    private double acumulador = 0;
    private String operadorPendiente = null;
    private boolean nuevaEntrada = true;
    private double ans = 0;
    private double memoria = 0;          // RF08 - RF11
    private boolean bloqueado = false;

    private final Label lblHistorial  = new Label("");
    private final Label lblPrincipal  = new Label("0");
    private final Label lblIndicadorM = new Label("");
    private final ObservableList<String> historial = FXCollections.observableArrayList();

    // RNF08: fondo oscuro, digitos y operandos claros
    private static final String FONDO    = "#17181A";
    private static final String PANEL    = "#0A0B0C";
    private static final String NUMERO   = "#2E2F33";
    private static final String OPERADOR = "#2563EB";
    private static final String LIMPIEZA = "#C62828";
    private static final String MEMORIA  = "#1F6F4A";   // RNF09
    private static final String CONTROL  = "#4B5563";
    private static final String TEXTO    = "#F5F4F0";

    @Override
    public void start(Stage stage) {
        VBox display = crearDisplay();
        GridPane teclado = crearTeclado();

        VBox izquierda = new VBox(14, display, teclado);
        izquierda.setPadding(new Insets(18));

        HBox raiz = new HBox(14, izquierda, crearPanelHistorial());
        raiz.setStyle("-fx-background-color: " + FONDO + ";");
        raiz.setPadding(new Insets(0, 18, 0, 0));

        Scene escena = new Scene(raiz, 640, 660);
        escena.addEventFilter(KeyEvent.KEY_PRESSED, this::teclado);

        stage.setTitle("Calculadora V3.0");
        stage.setScene(escena);
        stage.show();
    }

    private VBox crearDisplay() {
        lblHistorial.setFont(Font.font("Consolas", 14));
        lblHistorial.setStyle("-fx-text-fill: #9AA0A6;");
        lblHistorial.setMaxWidth(Double.MAX_VALUE);
        lblHistorial.setAlignment(Pos.CENTER_RIGHT);

        lblPrincipal.setFont(Font.font("Consolas", 40));
        lblPrincipal.setStyle("-fx-text-fill: " + TEXTO + ";");
        lblPrincipal.setMaxWidth(Double.MAX_VALUE);
        lblPrincipal.setAlignment(Pos.CENTER_RIGHT);

        lblIndicadorM.setFont(Font.font("Consolas", 14));
        lblIndicadorM.setStyle("-fx-text-fill: #4DA3FF;");

        HBox inferior = new HBox(lblIndicadorM);
        inferior.setAlignment(Pos.CENTER_LEFT);

        VBox caja = new VBox(4, lblHistorial, lblPrincipal, inferior);
        caja.setPadding(new Insets(16));
        caja.setStyle("-fx-background-color: " + PANEL + "; -fx-background-radius: 10;");
        caja.setMinHeight(130);
        caja.setPrefWidth(340);
        return caja;
    }

    private VBox crearPanelHistorial() {
        Label titulo = new Label("Historial de la sesión");
        titulo.setFont(Font.font("Segoe UI", 14));
        titulo.setStyle("-fx-text-fill: " + TEXTO + ";");

        ListView<String> lista = new ListView<>(historial);
        lista.setStyle("-fx-control-inner-background: " + PANEL + ";"
                     + "-fx-background-color: " + PANEL + ";"
                     + "-fx-text-fill: " + TEXTO + ";"
                     + "-fx-background-radius: 8;");
        VBox.setVgrow(lista, Priority.ALWAYS);

        Button limpiar = new Button("Limpiar historial");
        limpiar.setMaxWidth(Double.MAX_VALUE);
        limpiar.setStyle("-fx-background-color: " + CONTROL + "; -fx-text-fill: " + TEXTO
                       + "; -fx-background-radius: 8; -fx-cursor: hand;");
        limpiar.setOnAction(e -> historial.clear());

        VBox caja = new VBox(10, titulo, lista, limpiar);
        caja.setPadding(new Insets(18, 0, 18, 0));
        caja.setPrefWidth(240);
        return caja;
    }

    private GridPane crearTeclado() {
        GridPane g = new GridPane();
        g.setHgap(10);
        g.setVgap(10);
        g.setAlignment(Pos.CENTER);

        String[][] filas = {
            {"MC", "MR", "M+", "M-"},      // RF08 - RF11
            {"C", "CE", "%", "/"},
            {"7", "8", "9", "*"},
            {"4", "5", "6", "-"},
            {"1", "2", "3", "+"},
            {"+/-", "0", ".", "="}
        };
        for (int f = 0; f < filas.length; f++)
            for (int c = 0; c < filas[f].length; c++)
                g.add(crearBoton(filas[f][c]), c, f);
        return g;
    }

    /** RNF07: geometria cuadrada para todos los botones. */
    private Button crearBoton(String etiqueta) {
        Button b = new Button(etiqueta);
        b.setPrefSize(72, 72);
        b.setMinSize(72, 72);
        b.setFont(Font.font("Segoe UI", etiqueta.length() > 2 ? 15 : 19));

        String fondo;
        switch (etiqueta) {
            case "+": case "-": case "*": case "/": case "=": case "%":
                fondo = OPERADOR; break;
            case "C": case "CE":
                fondo = LIMPIEZA; break;
            case "MC": case "MR": case "M+": case "M-":
                fondo = MEMORIA; break;     // RNF09
            case "+/-":
                fondo = CONTROL; break;
            default:
                fondo = NUMERO;
        }
        String base = "-fx-background-color: " + fondo + ";"
                    + "-fx-text-fill: " + TEXTO + ";"
                    + "-fx-background-radius: 6;"   // cuadrado (RNF07)
                    + "-fx-border-radius: 6;"
                    + "-fx-cursor: hand;";
        b.setStyle(base);
        b.setOnMouseEntered(e -> b.setStyle(base + "-fx-opacity: 0.85;"));
        b.setOnMouseExited(e -> b.setStyle(base));
        b.setOnAction(e -> procesar(etiqueta));
        return b;
    }

    private void teclado(KeyEvent e) {
        String t = e.getText();
        if (t != null && t.length() == 1 && Character.isDigit(t.charAt(0))) { procesar(t); return; }
        if (".".equals(t) || ",".equals(t)) { procesar("."); return; }
        switch (t == null ? "" : t) {
            case "+": procesar("+"); return;
            case "-": procesar("-"); return;
            case "*": procesar("*"); return;
            case "/": procesar("/"); return;
            case "%": procesar("%"); return;
            case "=": procesar("="); return;
        }
        if (e.getCode() == KeyCode.ENTER)            procesar("=");
        else if (e.getCode() == KeyCode.BACK_SPACE)  procesar("CE");
        else if (e.getCode() == KeyCode.ESCAPE)      procesar("C");
    }

    private void procesar(String tecla) {
        if (bloqueado) return;
        switch (tecla) {
            case "MC": memoriaLimpiar();    break;   // RF09
            case "MR": memoriaRecuperar();  break;   // RF08
            case "M+": memoriaSumar();      break;   // RF10
            case "M-": memoriaRestar();     break;   // RF11
            case "C":  limpiarTodo();       break;
            case "CE": limpiarEntrada();    break;
            case "%":  porcentaje();        break;
            case "+/-":cambiarSigno();      break;
            case ".":  agregarPunto();      break;
            case "=":  igual();             break;
            case "+": case "-": case "*": case "/":
                       operador(tecla);     break;
            default:   agregarDigito(tecla);
        }
        refrescar();
    }

    // ---------------- Modulo de memoria ----------------

    /** RF09: limpia el valor de la memoria y lo deja en 0. */
    private void memoriaLimpiar() {
        memoria = 0;
        lblHistorial.setText("Memoria limpiada");
    }

    /** RF08: muestra el resultado que tenga la memoria en ese momento. */
    private void memoriaRecuperar() {
        entrada.setLength(0);
        entrada.append(formato(memoria));
        nuevaEntrada = false;
        lblHistorial.setText("MR = " + formato(memoria));
    }

    /** RF10: incrementa el valor que tenga MR. */
    private void memoriaSumar() {
        memoria += valorActual();            // RNF02: sin redondear el acumulador interno
        nuevaEntrada = true;
        lblHistorial.setText("M+ → M = " + formato(memoria));
        historial.add(0, "M+ " + formato(valorActual()) + "  |  M = " + formato(memoria));
    }

    /** RF11: decrementa el valor que tenga MR. */
    private void memoriaRestar() {
        memoria -= valorActual();
        nuevaEntrada = true;
        lblHistorial.setText("M- → M = " + formato(memoria));
        historial.add(0, "M- " + formato(valorActual()) + "  |  M = " + formato(memoria));
    }

    // ---------------- Logica aritmetica ----------------

    private void agregarDigito(String d) {
        if (nuevaEntrada) { entrada.setLength(0); nuevaEntrada = false; }
        if (entrada.toString().equals("0")) entrada.setLength(0);
        if (entrada.length() < 15) entrada.append(d);
        if (entrada.length() == 0) entrada.append("0");
    }

    private void agregarPunto() {
        if (nuevaEntrada) { entrada.setLength(0); entrada.append("0"); nuevaEntrada = false; }
        if (entrada.indexOf(".") < 0) entrada.append(".");
    }

    private void cambiarSigno() {
        if (entrada.toString().startsWith("-")) entrada.deleteCharAt(0);
        else if (!entrada.toString().equals("0")) entrada.insert(0, "-");
    }

    private void porcentaje() {
        double valor = valorActual();
        double resultado = (operadorPendiente == null) ? valor / 100.0 : acumulador * valor / 100.0;
        entrada.setLength(0);
        entrada.append(formato(resultado));
        nuevaEntrada = false;
    }

    private void operador(String op) {
        double valor = valorActual();
        if (operadorPendiente != null && !nuevaEntrada) {
            Double r = aplicar(acumulador, valor, operadorPendiente);
            if (r == null) return;
            acumulador = r;
        } else {
            acumulador = valor;
        }
        operadorPendiente = op;
        nuevaEntrada = true;
        lblHistorial.setText(formato(acumulador) + " " + op);
        entrada.setLength(0);
        entrada.append(formato(acumulador));
    }

    private void igual() {
        if (operadorPendiente == null) {
            ans = valorActual();
            lblHistorial.setText("ANS = " + formato(ans));
            return;
        }
        double derecho = valorActual();
        String expresion = formato(acumulador) + " " + operadorPendiente + " " + formato(derecho);
        Double r = aplicar(acumulador, derecho, operadorPendiente);
        if (r == null) return;

        acumulador = r;
        ans = r;
        entrada.setLength(0);
        entrada.append(formato(r));
        operadorPendiente = null;
        nuevaEntrada = true;
        lblHistorial.setText("ANS = " + formato(ans) + " | " + expresion);
        historial.add(0, expresion + " = " + formato(r));
    }

    private Double aplicar(double a, double b, String op) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/":
                if (b == 0) { errorDivisionEntreCero(); return null; }
                return a / b;
        }
        return b;
    }

    private void errorDivisionEntreCero() {
        bloqueado = true;
        lblHistorial.setText("");
        lblPrincipal.setFont(Font.font("Consolas", 22));
        lblPrincipal.setText("Error: División entre 0");
        historial.add(0, "Error: División entre 0");
        System.out.println("Error: División entre 0");

        PauseTransition espera = new PauseTransition(Duration.seconds(2.5));
        espera.setOnFinished(e -> Platform.exit());
        espera.play();
    }

    /** CE: limpia la operacion actual. No afecta la memoria. */
    private void limpiarEntrada() {
        entrada.setLength(0);
        entrada.append("0");
        nuevaEntrada = true;
    }

    /** C / AC: limpia todo el calculo. La memoria solo se borra con MC. */
    private void limpiarTodo() {
        limpiarEntrada();
        acumulador = 0;
        operadorPendiente = null;
        lblHistorial.setText("");
    }

    private double valorActual() {
        try { return Double.parseDouble(entrada.toString()); }
        catch (NumberFormatException e) { return 0; }
    }

    private String formato(double v) {
        BigDecimal bd = BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString();
    }

    private void refrescar() {
        if (bloqueado) return;
        String texto = entrada.toString();
        if (!texto.endsWith(".") && !texto.isEmpty()) {
            try { texto = formato(Double.parseDouble(texto)); }
            catch (NumberFormatException ignored) { }
        }
        lblPrincipal.setText(texto);
        lblIndicadorM.setText(memoria != 0 ? "M = " + formato(memoria) : "");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
