package com.mycompany.calculadora;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Calculadora V1.0 - Modelos de Prueba de Software
 *
 * Requerimientos implementados:
 *  RF01 Operaciones basicas (+, -, *, /)
 *  RF02 Manejo de error de division entre cero: muestra "Error: Division entre 0" y cierra el programa
 *  RF03 Limpiar pantalla: CE (operacion actual) y C/AC (todo), display regresa a 0
 *  RF04 Funcion ANS: reutiliza el ultimo resultado
 *  RF05 Formato de salida: maximo 2 decimales
 *  RF06 Entrada de datos por botones (0-9 y punto decimal)
 *  RF07 Historial en el renglon superior del display
 *  RNF01 Operadores diferenciados por color / RNF02 precision interna
 *  RNF03 Idioma espanol / RNF04 excepciones de entrada
 *  RNF05 Botones redondos / RNF06 Dark Mode de alto contraste
 */
public class CalculadoraV1 extends Application {

    // ---------------- Estado logico ----------------
    private final StringBuilder entrada = new StringBuilder("0");
    private double acumulador = 0;      // RNF02: precision flotante completa
    private String operadorPendiente = null;
    private boolean nuevaEntrada = true;
    private double ans = 0;             // RF04
    private boolean bloqueado = false;  // RF02: tras el error se bloquea la botonera

    // ---------------- Interfaz ----------------
    private final Label lblHistorial = new Label("");   // RF07
    private final Label lblPrincipal = new Label("0");

    // Paleta (RNF06 Dark Mode)
    private static final String FONDO       = "#17181A";
    private static final String PANEL       = "#0D0E10";
    private static final String NUMERO      = "#3C3C3C"; // gris carbon
    private static final String OPERADOR    = "#2563EB"; // azul vibrante
    private static final String LIMPIEZA    = "#C62828"; // rojo de alerta
    private static final String MEMORIA     = "#4B5563"; // ANS
    private static final String TEXTO       = "#F5F4F0";

    @Override
    public void start(Stage stage) {
        VBox display = crearDisplay();
        GridPane teclado = crearTeclado();

        VBox raiz = new VBox(14, display, teclado);
        raiz.setPadding(new Insets(18));
        raiz.setStyle("-fx-background-color: " + FONDO + ";");

        Scene escena = new Scene(raiz, 360, 560);
        escena.setOnKeyPressed(e -> { /* V1: la entrada es unicamente por botones (RF06) */ });

        stage.setTitle("Calculadora V1.0");
        stage.setScene(escena);
        stage.setResizable(false);
        stage.show();
    }

    private VBox crearDisplay() {
        lblHistorial.setFont(Font.font("Consolas", 14));
        lblHistorial.setStyle("-fx-text-fill: #9AA0A6;");
        lblHistorial.setMaxWidth(Double.MAX_VALUE);
        lblHistorial.setAlignment(Pos.CENTER_RIGHT);

        lblPrincipal.setFont(Font.font("Consolas", 40));
        lblPrincipal.setStyle("-fx-text-fill: " + TEXTO + ";");
        lblPrincipal.setMaxWidth(Double.MAX_VALUE);
        lblPrincipal.setAlignment(Pos.CENTER_RIGHT);

        VBox caja = new VBox(6, lblHistorial, lblPrincipal);
        caja.setPadding(new Insets(16));
        caja.setAlignment(Pos.CENTER_RIGHT);
        caja.setStyle("-fx-background-color: " + PANEL + "; -fx-background-radius: 14;");
        caja.setMinHeight(120);
        return caja;
    }

    private GridPane crearTeclado() {
        GridPane g = new GridPane();
        g.setHgap(12);
        g.setVgap(12);
        g.setAlignment(Pos.CENTER);

        String[][] filas = {
            {"C", "CE", "ANS", "/"},
            {"7", "8", "9", "*"},
            {"4", "5", "6", "-"},
            {"1", "2", "3", "+"},
            {"0", ".", "+/-", "="}
        };

        for (int f = 0; f < filas.length; f++) {
            for (int c = 0; c < filas[f].length; c++) {
                g.add(crearBoton(filas[f][c]), c, f);
            }
        }
        return g;
    }

    /** RNF05: todos los botones son circulares. */
    private Button crearBoton(String etiqueta) {
        Button b = new Button(etiqueta);
        b.setPrefSize(70, 70);
        b.setMinSize(70, 70);
        b.setFont(Font.font("Segoe UI", etiqueta.length() > 2 ? 15 : 19));

        String fondo;
        switch (etiqueta) {
            case "+": case "-": case "*": case "/": case "=":
                fondo = OPERADOR; break;          // RNF01
            case "C": case "CE":
                fondo = LIMPIEZA; break;          // RF03
            case "ANS":
                fondo = MEMORIA; break;           // RF04
            default:
                fondo = NUMERO;                   // RF06
        }

        String base = "-fx-background-color: " + fondo + ";"
                    + "-fx-text-fill: " + TEXTO + ";"
                    + "-fx-background-radius: 35;"   // circulo
                    + "-fx-cursor: hand;";
        b.setStyle(base);
        b.setOnMouseEntered(e -> b.setStyle(base + "-fx-opacity: 0.85;"));
        b.setOnMouseExited(e -> b.setStyle(base));
        b.setOnAction(e -> procesar(etiqueta));
        return b;
    }

    // ---------------- Logica ----------------
    private void procesar(String tecla) {
        if (bloqueado) return;

        switch (tecla) {
            case "C":   limpiarTodo();       break;   // RF03
            case "CE":  limpiarEntrada();    break;   // RF03
            case "ANS": usarAns();           break;   // RF04
            case "+/-": cambiarSigno();      break;
            case ".":   agregarPunto();      break;   // RNF04
            case "=":   igual();             break;
            case "+": case "-": case "*": case "/":
                        operador(tecla);     break;   // RF01
            default:    agregarDigito(tecla);         // RF06
        }
        refrescar();
    }

    private void agregarDigito(String d) {
        if (nuevaEntrada) {
            entrada.setLength(0);
            nuevaEntrada = false;
        }
        if (entrada.toString().equals("0")) entrada.setLength(0);
        if (entrada.length() < 15) entrada.append(d);
        if (entrada.length() == 0) entrada.append("0");
    }

    /** RNF04: impide dos puntos decimales en el mismo operando. */
    private void agregarPunto() {
        if (nuevaEntrada) {
            entrada.setLength(0);
            entrada.append("0");
            nuevaEntrada = false;
        }
        if (entrada.indexOf(".") < 0) entrada.append(".");
    }

    private void cambiarSigno() {
        if (entrada.toString().startsWith("-")) entrada.deleteCharAt(0);
        else if (!entrada.toString().equals("0")) entrada.insert(0, "-");
    }

    private void operador(String op) {
        double valor = valorActual();
        if (operadorPendiente != null && !nuevaEntrada) {
            Double r = aplicar(acumulador, valor, operadorPendiente);
            if (r == null) return;              // se produjo el error de division entre 0
            acumulador = r;
        } else {
            acumulador = valor;
        }
        operadorPendiente = op;
        nuevaEntrada = true;
        lblHistorial.setText(formato(acumulador) + " " + op);   // RF07
        entrada.setLength(0);
        entrada.append(formato(acumulador));
    }

    private void igual() {
        if (operadorPendiente == null) {
            ans = valorActual();
            lblHistorial.setText("ANS = " + formato(ans));
            return;
        }
        double derecho = valorActual();
        String expresion = formato(acumulador) + " " + operadorPendiente + " " + formato(derecho);

        Double r = aplicar(acumulador, derecho, operadorPendiente);
        if (r == null) return;                  // RF02

        acumulador = r;
        ans = r;                                // RF04
        entrada.setLength(0);
        entrada.append(formato(r));
        operadorPendiente = null;
        nuevaEntrada = true;
        lblHistorial.setText("ANS = " + formato(ans) + " | " + expresion);  // RF07
    }

    /** RF01 y RF02. Devuelve null cuando ocurre division entre cero. */
    private Double aplicar(double a, double b, String op) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/":
                if (b == 0) { errorDivisionEntreCero(); return null; }
                return a / b;
        }
        return b;
    }

    /** RF02 / RNF03: mensaje exacto en espanol y cierre del programa. */
    private void errorDivisionEntreCero() {
        bloqueado = true;
        lblHistorial.setText("");
        lblPrincipal.setFont(Font.font("Consolas", 22));
        lblPrincipal.setText("Error: División entre 0");
        System.out.println("Error: División entre 0");

        PauseTransition espera = new PauseTransition(Duration.seconds(2.5));
        espera.setOnFinished(e -> Platform.exit());
        espera.play();
    }

    private void usarAns() {   // RF04
        entrada.setLength(0);
        entrada.append(formato(ans));
        nuevaEntrada = false;
        lblHistorial.setText("ANS = " + formato(ans));
    }

    private void limpiarEntrada() {   // CE
        entrada.setLength(0);
        entrada.append("0");
        nuevaEntrada = true;
    }

    private void limpiarTodo() {      // C / AC
        limpiarEntrada();
        acumulador = 0;
        operadorPendiente = null;
        lblHistorial.setText("");
    }

    private double valorActual() {
        try { return Double.parseDouble(entrada.toString()); }
        catch (NumberFormatException e) { return 0; }
    }

    /** RF05: maximo 2 decimales en pantalla (RNF02: el calculo interno no se redondea). */
    private String formato(double v) {
        BigDecimal bd = BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString();
    }

    private void refrescar() {
        if (bloqueado) return;
        String texto = entrada.toString();
        if (!texto.endsWith(".") && !texto.isEmpty()) {
            try { texto = formato(Double.parseDouble(texto)); }
            catch (NumberFormatException ignored) { }
        }
        lblPrincipal.setText(texto);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
