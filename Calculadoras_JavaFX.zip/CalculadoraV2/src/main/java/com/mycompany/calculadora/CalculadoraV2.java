package com.mycompany.calculadora;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Calculadora V2.0 - Modelos de Prueba de Software
 *
 * Agrega sobre la V1.0:
 *  RF-04.1 Porcentaje (%)
 *  RF-06   Entrada por teclado fisico ademas de los botones
 *  RF-08   Historial de operaciones de la sesion
 *  RF-10   Calculo secuencial y RF-10.1 uso acumulativo del resultado anterior
 *  RF-11   Tecla de borrado (retroceso)
 *  RF-12   AC (All Clear) y RF-12.1 cambio de signo
 *  RNF-04  Paleta neutra de alto contraste (ambar / verde oliva)
 *  RNF-05  Geometria circular y simetria de 4 columnas
 */
public class CalculadoraV2 extends Application {

    private final StringBuilder entrada = new StringBuilder("0");
    private double acumulador = 0;
    private String operadorPendiente = null;
    private boolean nuevaEntrada = true;
    private double ans = 0;
    private boolean bloqueado = false;

    private final Label lblHistorial = new Label("");
    private final Label lblPrincipal = new Label("0");
    private final ObservableList<String> historial = FXCollections.observableArrayList();

    private static final String FONDO    = "#17181A";
    private static final String PANEL    = "#0D0E10";
    private static final String NUMERO   = "#3C3C3C";
    private static final String ACCION   = "#E08A1E"; // ambar: operadores
    private static final String CONTROL  = "#5C6B2F"; // verde oliva: AC y borrado
    private static final String TEXTO    = "#F5F4F0";
    private static final String DIGITOS  = "#E0D06A";

    @Override
    public void start(Stage stage) {
        VBox display = crearDisplay();
        GridPane teclado = crearTeclado();

        VBox izquierda = new VBox(14, display, teclado);
        izquierda.setPadding(new Insets(18));

        VBox panelHistorial = crearPanelHistorial();

        HBox raiz = new HBox(14, izquierda, panelHistorial);
        raiz.setStyle("-fx-background-color: " + FONDO + ";");
        raiz.setPadding(new Insets(0, 18, 0, 0));

        Scene escena = new Scene(raiz, 620, 580);
        escena.addEventFilter(KeyEvent.KEY_PRESSED, this::teclado);  // RF-06

        stage.setTitle("Calculadora V2.0");
        stage.setScene(escena);
        stage.show();
    }

    private VBox crearDisplay() {
        lblHistorial.setFont(Font.font("Consolas", 14));
        lblHistorial.setStyle("-fx-text-fill: #9AA0A6;");
        lblHistorial.setMaxWidth(Double.MAX_VALUE);
        lblHistorial.setAlignment(Pos.CENTER_RIGHT);

        lblPrincipal.setFont(Font.font("Consolas", 40));
        lblPrincipal.setStyle("-fx-text-fill: " + DIGITOS + ";");
        lblPrincipal.setMaxWidth(Double.MAX_VALUE);
        lblPrincipal.setAlignment(Pos.CENTER_RIGHT);

        VBox caja = new VBox(6, lblHistorial, lblPrincipal);
        caja.setPadding(new Insets(16));
        caja.setAlignment(Pos.CENTER_RIGHT);
        caja.setStyle("-fx-background-color: " + PANEL + "; -fx-background-radius: 14;");
        caja.setMinHeight(120);
        caja.setPrefWidth(330);
        return caja;
    }

    private VBox crearPanelHistorial() {   // RF-08
        Label titulo = new Label("Historial de la sesión");
        titulo.setFont(Font.font("Segoe UI", 14));
        titulo.setStyle("-fx-text-fill: " + TEXTO + ";");

        ListView<String> lista = new ListView<>(historial);
        lista.setStyle("-fx-control-inner-background: " + PANEL + ";"
                     + "-fx-background-color: " + PANEL + ";"
                     + "-fx-text-fill: " + TEXTO + ";"
                     + "-fx-background-radius: 10;");
        VBox.setVgrow(lista, Priority.ALWAYS);

        Button limpiar = new Button("Limpiar historial");
        limpiar.setMaxWidth(Double.MAX_VALUE);
        limpiar.setStyle("-fx-background-color: " + CONTROL + "; -fx-text-fill: " + TEXTO
                       + "; -fx-background-radius: 10; -fx-cursor: hand;");
        limpiar.setOnAction(e -> historial.clear());

        VBox caja = new VBox(10, titulo, lista, limpiar);
        caja.setPadding(new Insets(18, 0, 18, 0));
        caja.setPrefWidth(240);
        return caja;
    }

    private GridPane crearTeclado() {
        GridPane g = new GridPane();
        g.setHgap(12);
        g.setVgap(12);
        g.setAlignment(Pos.CENTER);

        String[][] filas = {
            {"AC", "\u232B", "%", "/"},
            {"7", "8", "9", "*"},
            {"4", "5", "6", "-"},
            {"1", "2", "3", "+"},
            {"+/-", "0", ".", "="}
        };
        for (int f = 0; f < filas.length; f++)
            for (int c = 0; c < filas[f].length; c++)
                g.add(crearBoton(filas[f][c]), c, f);
        return g;
    }

    /** RNF-05: geometria circular, simetria de 4 columnas. */
    private Button crearBoton(String etiqueta) {
        Button b = new Button(etiqueta);
        b.setPrefSize(70, 70);
        b.setMinSize(70, 70);
        b.setFont(Font.font("Segoe UI", etiqueta.length() > 2 ? 15 : 19));

        String fondo;
        switch (etiqueta) {
            case "+": case "-": case "*": case "/": case "=": case "%":
                fondo = ACCION; break;
            case "AC": case "\u232B":
                fondo = CONTROL; break;
            default:
                fondo = NUMERO;
        }
        String base = "-fx-background-color: " + fondo + ";"
                    + "-fx-text-fill: " + TEXTO + ";"
                    + "-fx-background-radius: 35;"
                    + "-fx-cursor: hand;";
        b.setStyle(base);
        b.setOnMouseEntered(e -> b.setStyle(base + "-fx-opacity: 0.85;"));
        b.setOnMouseExited(e -> b.setStyle(base));
        b.setOnAction(e -> procesar(etiqueta));
        return b;
    }

    /** RF-06: entrada equivalente mediante teclado fisico. */
    private void teclado(KeyEvent e) {
        String t = e.getText();
        if (t != null && t.length() == 1 && Character.isDigit(t.charAt(0))) { procesar(t); return; }
        if (".".equals(t) || ",".equals(t)) { procesar("."); return; }
        switch (t == null ? "" : t) {
            case "+": procesar("+"); return;
            case "-": procesar("-"); return;
            case "*": procesar("*"); return;
            case "/": procesar("/"); return;
            case "%": procesar("%"); return;
            case "=": procesar("="); return;
        }
        if (e.getCode() == KeyCode.ENTER)      procesar("=");
        else if (e.getCode() == KeyCode.BACK_SPACE) procesar("\u232B");
        else if (e.getCode() == KeyCode.ESCAPE)     procesar("AC");
    }

    private void procesar(String tecla) {
        if (bloqueado) return;
        switch (tecla) {
            case "AC":     limpiarTodo();   break;   // RF-12
            case "\u232B": retroceso();     break;   // RF-11
            case "+/-":    cambiarSigno();  break;   // RF-12.1
            case "%":      porcentaje();    break;   // RF-04.1
            case ".":      agregarPunto();  break;   // RF-13.1
            case "=":      igual();         break;
            case "+": case "-": case "*": case "/":
                           operador(tecla); break;
            default:       agregarDigito(tecla);
        }
        refrescar();
    }

    private void agregarDigito(String d) {
        if (nuevaEntrada) { entrada.setLength(0); nuevaEntrada = false; }
        if (entrada.toString().equals("0")) entrada.setLength(0);
        if (entrada.length() < 15) entrada.append(d);
        if (entrada.length() == 0) entrada.append("0");
    }

    private void agregarPunto() {
        if (nuevaEntrada) { entrada.setLength(0); entrada.append("0"); nuevaEntrada = false; }
        if (entrada.indexOf(".") < 0) entrada.append(".");
    }

    /** RF-11: elimina la ultima entrada sin afectar la operacion en curso. */
    private void retroceso() {
        if (nuevaEntrada) return;
        if (entrada.length() > 0) entrada.deleteCharAt(entrada.length() - 1);
        if (entrada.length() == 0 || entrada.toString().equals("-")) {
            entrada.setLength(0);
            entrada.append("0");
            nuevaEntrada = true;
        }
    }

    private void cambiarSigno() {
        if (entrada.toString().startsWith("-")) entrada.deleteCharAt(0);
        else if (!entrada.toString().equals("0")) entrada.insert(0, "-");
    }

    /** RF-04.1: porcentaje del operando dentro de la expresion. */
    private void porcentaje() {
        double valor = valorActual();
        double resultado = (operadorPendiente == null) ? valor / 100.0 : acumulador * valor / 100.0;
        entrada.setLength(0);
        entrada.append(formato(resultado));
        nuevaEntrada = false;
    }

    /** RF-10: calculo secuencial encadenado. */
    private void operador(String op) {
        double valor = valorActual();
        if (operadorPendiente != null && !nuevaEntrada) {
            Double r = aplicar(acumulador, valor, operadorPendiente);
            if (r == null) return;
            acumulador = r;
        } else {
            acumulador = valor;
        }
        operadorPendiente = op;
        nuevaEntrada = true;
        lblHistorial.setText(formato(acumulador) + " " + op);
        entrada.setLength(0);
        entrada.append(formato(acumulador));
    }

    private void igual() {
        if (operadorPendiente == null) {
            ans = valorActual();
            lblHistorial.setText("ANS = " + formato(ans));
            return;
        }
        double derecho = valorActual();
        String expresion = formato(acumulador) + " " + operadorPendiente + " " + formato(derecho);
        Double r = aplicar(acumulador, derecho, operadorPendiente);
        if (r == null) return;

        acumulador = r;
        ans = r;                       // RF-10.1: queda disponible como primer operando
        entrada.setLength(0);
        entrada.append(formato(r));
        operadorPendiente = null;
        nuevaEntrada = true;
        lblHistorial.setText(expresion + " =");
        historial.add(0, expresion + " = " + formato(r));   // RF-08
    }

    private Double aplicar(double a, double b, String op) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/":
                if (b == 0) { errorDivisionEntreCero(); return null; }   // RF-14 / RF-15
                return a / b;
        }
        return b;
    }

    private void errorDivisionEntreCero() {
        bloqueado = true;
        lblHistorial.setText("");
        lblPrincipal.setFont(Font.font("Consolas", 22));
        lblPrincipal.setText("Error: División entre 0");
        historial.add(0, "Error: División entre 0");
        System.out.println("Error: División entre 0");

        PauseTransition espera = new PauseTransition(Duration.seconds(2.5));
        espera.setOnFinished(e -> Platform.exit());
        espera.play();
    }

    private void limpiarTodo() {
        entrada.setLength(0);
        entrada.append("0");
        nuevaEntrada = true;
        acumulador = 0;
        operadorPendiente = null;
        lblHistorial.setText("");
    }

    private double valorActual() {
        try { return Double.parseDouble(entrada.toString()); }
        catch (NumberFormatException e) { return 0; }
    }

    /** RF-09: maximo dos decimales en pantalla. */
    private String formato(double v) {
        BigDecimal bd = BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString();
    }

    private void refrescar() {
        if (bloqueado) return;
        String texto = entrada.toString();
        if (!texto.endsWith(".") && !texto.isEmpty()) {
            try { texto = formato(Double.parseDouble(texto)); }
            catch (NumberFormatException ignored) { }
        }
        lblPrincipal.setText(texto);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
